#include "lib.hpp"
using namespace std;

int main() {

Matrix x(2,1);
double lambdak = 2.0;
Matrix xkk(2,1,0.0);
	Matrix m = invhessg(hessfa, lambdak, x, xkk);

m.debug();
return 0;
}
