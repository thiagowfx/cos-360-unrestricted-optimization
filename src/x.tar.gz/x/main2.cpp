#include "libnewtonpuro.hpp"
using namespace std;

int main(int argc, char **argv) {
  // Semente para números aleatórios.
  srand(time(NULL)); // time(NULL): número de segundos desde ~1970  --> gerar uma semente diferente a cada execução

  // set cout precision globally
  std::cout << std::fixed << std::setprecision(10);

  // solve_it(FB, Matrix(vector<double>{3.0,1.0}), 4, 1e-7, 1e-2, GRADIENT);

// forma 1 de declarar matrix:
	// Matrix m;
	// m.set(1, 3.0);
	// m.set(2, 1.0);

// forma 2: Matrix(vector<double>{3.0,1.0})

  //Matrix ans = solve_it(
	//FA,
	//Matrix(vector<double>{3.0,1.0}),
	//10,
	//1e-7,
	//1e-5,
	//GRADIENT
//);

  Matrix ans = solve_it(
	FA,
	Matrix(vector<double>{1.0, 1.0}),
	4,
	1e-7,
	1e-5,
	NEWTON
);

  std::cout << "Error 1: " << (ans - Matrix(vector<double>{0.0,1.0})).mod() << std::endl;
  std::cout << "Error 2: " << fa(ans) - fa(Matrix(vector<double>{0.0,1.0})) << std::endl;

  return 0;
}


